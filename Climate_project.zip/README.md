# Dockerで動かす手順

## 必要なもの
- Docker Desktop（インストール済みであること）
  - まだの場合：https://www.docker.com/products/docker-desktop/

---

## ファイル構成（このフォルダに全部置く）

```
📁 climate_project/
├── Dockerfile
├── requirements.txt
├── climate_trend_analysis.py
└── Climate_data.csv
```

---

## 実行手順（コマンド2つだけ！）

### ① 箱（イメージ）を作る

```bash
docker build -t climate-analysis .
```

- `docker build` ：Dockerfileを読んで箱を組み立てる命令
- `-t climate-analysis` ：箱に「climate-analysis」という名前をつける
- `.` ：「今いるフォルダ」のDockerfileを使うという意味

初回は数分かかります（ライブラリのダウンロードがあるため）。

---

### ② 箱を動かして結果を取り出す

```bash
docker run --rm -v "$(pwd)/output:/app/output" climate-analysis
```

- `docker run` ：箱を起動する命令
- `--rm` ：実行後にコンテナを自動削除（後片付け）
- `-v "$(pwd)/output:/app/output"` ：結果ファイルを手元に取り出すための橋渡し設定
- `climate-analysis` ：起動する箱の名前

実行すると `output/` フォルダに `climate_trend_analysis.png` が出力されます。

---

## ✅ 用語まとめ

| 言葉 | 意味 |
|------|------|
| Dockerfile | 箱の設計図 |
| イメージ（Image） | 設計図から作った「箱のひな形」 |
| コンテナ（Container） | 実際に起動して動いている箱 |
| `docker build` | 設計図→ひな形を作るコマンド |
| `docker run` | ひな形→起動して実行するコマンド |

---

## よくあるトラブル

**Q. `docker: command not found` と出る**
→ Docker Desktopがインストールされていないか、起動していません。

**Q. `Cannot connect to the Docker daemon` と出る**
→ Docker Desktopのアプリが起動していません。タスクトレイを確認してください。
